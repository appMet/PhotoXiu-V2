# PhotoXiu V2 - Android Studio project

Aplikasi starter kit fotografi offline berbasis Android WebView. Proyek ini adalah **source project**, bukan APK yang sudah dikompilasi.

## Cara membuka dan membangun APK
1. Ekstrak ZIP.
2. Buka folder `PhotoXiuV2` melalui Android Studio (versi yang mendukung Android Gradle Plugin 8.7.3).
3. Tunggu Gradle Sync. Pastikan Android SDK Platform 35 terpasang.
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug akan muncul di `app/build/outputs/apk/debug/app-debug.apk`.

## Isi
- 30 setting situasi fotografi dengan cara pakai dan hal yang perlu dihindari.
- White Balance untuk pengguna HP.
- 10 composition rules.
- 15 ide pose dengan ilustrasi visual sederhana (bukan foto referensi asli).
- Direksi pose, lighting, troubleshooting, editing workflow.
- Challenge 30 hari dengan progres tersimpan lokal.
- Video Corner sebagai materi tambahan.

Semua materi diakses offline. Proyek ini tidak membutuhkan izin internet.
